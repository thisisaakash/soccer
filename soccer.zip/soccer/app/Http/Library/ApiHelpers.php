<?php
namespace App\Http\Library;

use DB;
use Illuminate\Http\JsonResponse;

trait ApiHelpers
{
    protected function getRolesPermission($id){
        $rolesPermission = DB::table('roles_permission')->where('id', $id)->first();
        return $rolesPermission->permission;
    }

    protected function isAllowed($user, $access): bool {
        if (!empty($user)) {
            $permissionRaw = $this->getRolesPermission($user->role);
            if($permissionRaw == '*'){
                return true;
            } else {
                $permission = explode(",",$permissionRaw);
                if(in_array($access,$permission)){
                    return true;
                }
            }
        }
        return false;
    }
}
?>
