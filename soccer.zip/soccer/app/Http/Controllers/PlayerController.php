<?php

namespace App\Http\Controllers;

use DB;
use App\Http\Library\ApiHelpers;
use App\Models\Player;
use App\Models\Team;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PlayerController extends Controller
{
    use ApiHelpers;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return response()->json([
            'message'       => 'Player List',
            'statusMessage' => 'success',
            'statusCode'    => 200,
            'data' => Player::get()
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if ($this->isAllowed($request->user(),'create')) {
            $validator = Validator::make($request->all(), [
                'teams_id' => 'required',
                'first_name' => 'required',
                'last_name' => 'required',
                'player_image_url' => 'required',
            ]);
            if ($validator->fails()) {
                return response()->json([
                    'message'       => 'Validation Failed',
                    'statusMessage' => 'failure',
                    'statusCode'    => 400,
                    'error'         => $validator->errors(),
                    'data'          => $request->all()
                ]);
            } else {
                if ($this->teamExist($request->teams_id)) {
                    if ($this->playerExist($request->all())) {
                        return response()->json([
                            'message'       => 'Player Already Exist',
                            'statusMessage' => 'failure',
                            'statusCode'    => 409,
                            'data'          => $request->all()
                        ]);
                    } else {
                        $player = new Player;
                        $player->teams_id = $request->teams_id;
                        $player->first_name = $request->first_name;
                        $player->last_name = $request->last_name;
                        $player->player_image_url = $request->player_image_url;
                        $player->save();
                        return response()->json([
                            'message'       => 'Player Added Successfully',
                            'statusMessage' => 'success',
                            'statusCode'    => 201,
                            'data'          => $player
                        ]);
                    }
                } else {
                    return response()->json([
                        'message'       => 'Team Not Exist',
                        'statusMessage' => 'failure',
                        'statusCode'    => 404,
                        'data'          => $request->all()
                    ]);
                }
            }
        } else {
            return response()->json([
                'message'       => 'Unauthorized Access',
                'statusMessage' => 'unauthorized',
                'statusCode'    => 400,
                'data'          => $request->all()
            ]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Player  $player
     * @return \Illuminate\Http\Response
     */
    public function show(Player $player)
    {
        return response()->json([
            'message'       => 'Player Details',
            'statusMessage' => 'success',
            'statusCode'    => 200,
            'data'          => $player
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Player  $player
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Player $player)
    {
        if ($this->isAllowed($request->user(),'update')) {
            $validator = Validator::make($request->all(), [
                'teams_id' => 'required',
                'first_name' => 'required',
                'last_name' => 'required',
                'player_image_url' => 'required',
            ]);
            if ($validator->fails()) {
                return response()->json([
                    'message'       => 'Validation Failed',
                    'statusMessage' => 'failure',
                    'statusCode'    => 400,
                    'error'         => $validator->errors(),
                    'data'          => $request->all()
                ]);
            } else {
                if ($this->teamExist($request->teams_id)) {
                    if ($this->playerExist($request->all())) {
                        return response()->json([
                            'message'       => 'Player Already Exist',
                            'statusMessage' => 'failure',
                            'statusCode'    => 409,
                            'data'          => $request->all()
                        ]);
                    } else {
                        $player->teams_id = $request->teams_id;
                        $player->first_name = $request->first_name;
                        $player->last_name = $request->last_name;
                        $player->player_image_url = $request->player_image_url;
                        $player->save();
                        return response()->json([
                            'message'       => 'Player Updated Successfully',
                            'statusMessage' => 'success',
                            'statusCode'    => 200,
                            'data'          => $player
                        ]);
                    }
                } else {
                    return response()->json([
                        'message'       => 'Team Not Exist',
                        'statusMessage' => 'failure',
                        'statusCode'    => 404,
                        'data'          => $request->all()
                    ]);
                }
            }
        } else {
            return response()->json([
                'message'       => 'Unauthorized Access',
                'statusMessage' => 'unauthorized',
                'statusCode'    => 400,
                'data'          => $request->all()
            ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Player  $player
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, Player $player)
    {
        if ($this->isAllowed($request->user(),'delete')) {
            $player->delete();
            return response()->json([
                'message'       => 'Player Deleted Successfully',
                'statusMessage' => 'success',
                'statusCode'    => 200
            ]);
        } else {
            return response()->json([
                'message'       => 'Unauthorized Access',
                'statusMessage' => 'unauthorized',
                'statusCode'    => 400,
                'data'          => $request->all()
            ]);
        }
    }

    // Custom Functions Start
    private function teamExist($id){
        if(Team::where('id', $id)->exists()){
            return true;
        } else {
            return false;
        }
    }

    private function getTeamByName($name){
        return DB::table('teams')->where('name', $name)->first();
    }

    private function playerExist($request){
        $request = (object) $request;
        if(Player::where('teams_id', $request->teams_id)->where('first_name', $request->first_name)->where('last_name', $request->last_name)->exists()){
            return true;
        } else {
            return false;
        }
    }

    public function getTeamPlayers(Request $request){
        $teamExist = false;
        $segments = $request->segments();
        $team = $segments[2];
        if(is_numeric($team)){
            if($this->teamExist((int)$team)){
                $teamExist = true;
                $players = DB::table('players')->where('teams_id', $team)->get();
            }
        } else {
            $teamData = $this->getTeamByName($team);
            if($teamData){
                $teamExist = true;
                $players = DB::table('players')->where('teams_id', $teamData->id)->get();
            }
        }
        if($teamExist){
            return response()->json([
                'message'       => 'Player List',
                'statusMessage' => 'success',
                'statusCode'    => 200,
                'data'          => $players
            ]);
        } else {
            return response()->json([
                'message'       => 'Team Not Exist',
                'statusMessage' => 'failure',
                'statusCode'    => 404,
                'data'          => $team
            ]);
        }
    }
    // Custom Functions End
}
