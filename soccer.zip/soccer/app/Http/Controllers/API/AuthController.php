<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use Validator;
use App\Models\User;

class AuthController extends Controller
{
    public function register(Request $request){
        $validator = Validator::make($request->all(),[
            'name'              => 'required',
            'role'              => 'required',
            'email'             => 'required|email',
            'password'          => 'required',
            'confirm_password'  => 'required|same:password'
        ]);
        if($validator->fails()){
            return response()->json([
                'message'       => $validator->errors(),
                'statusMessage' => 'failure',
                'statusCode'    => 400
            ]);
        } else {
            $input = $request->all();
            $input['password'] = bcrypt($input['password']);
            $user = User::create($input);
            return response()->json([
                'message'       => 'User Registered Successfully',
                'statusMessage' => 'success',
                'statusCode'    => 201,
                'token'         => $user->createToken('Soccer')->plainTextToken,
                'name'          => $request->name,
                'role'          => $request->role,
                'email'         => $request->email
            ]);
        }
    }

    public function login(Request $request){
        if(Auth::attempt(['email'=>$request->email,'password'=>$request->password])){
            $user = Auth::user();
            return response()->json([
                'message'       => 'Logged In Successfully',
                'statusMessage' => 'success',
                'statusCode'    => 200,
                'token'         => $user->createToken('Soccer')->plainTextToken,
                'email'         => $request->email
            ]);
        } else {
            return response()->json([
                'message'       => 'Login Failed',
                'statusMessage' => 'failure',
                'statusCode'    => 400,
                'email'         => $request->email
            ]);
        }
    }
}
