<?php

namespace App\Http\Controllers;

use App\Http\Library\ApiHelpers;
use App\Models\Team;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TeamController extends Controller
{
    use ApiHelpers;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        return response()->json([
            'message'       => 'Team List',
            'statusMessage' => 'success',
            'statusCode'    => 200,
            'data' => Team::get()
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if ($this->isAllowed($request->user(),'create')) {
            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'logo_url' => 'required'
            ]);
            if ($validator->fails()) {
                return response()->json([
                    'message'       => 'Validation Failed',
                    'statusMessage' => 'failure',
                    'statusCode'    => 400,
                    'error'         => $validator->errors(),
                    'data'          => $request->all()
                ]);
            } else {
                if ($this->teamExist($request->name)) {
                    return response()->json([
                        'message'       => 'Team Already Exist',
                        'statusMessage' => 'failure',
                        'statusCode'    => 409,
                        'data'          => $request->all()
                    ]);
                } else {
                    $team = new Team;
                    $team->name = $request->name;
                    $team->logo_url = $request->logo_url;
                    $team->save();
                    return response()->json([
                        'message'       => 'Team Added Successfully',
                        'statusMessage' => 'success',
                        'statusCode'    => 201,
                        'data'          => $team
                    ]);
                }
            }
        } else {
            return response()->json([
                'message'       => 'Unauthorized Access',
                'statusMessage' => 'unauthorized',
                'statusCode'    => 400,
                'data'          => $request->all()
            ]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Team  $team
     * @return \Illuminate\Http\Response
     */
    public function show(Team $team)
    {
        return response()->json([
            'message'       => 'Team Details',
            'statusMessage' => 'success',
            'statusCode'    => 200,
            'data'          => $team
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Team  $team
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Team $team)
    {
        if ($this->isAllowed($request->user(),'update')) {
            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'logo_url' => 'required'
            ]);
            if ($validator->fails()) {
                return response()->json([
                    'message'       => 'Validation Failed',
                    'statusMessage' => 'failure',
                    'statusCode'    => 400,
                    'error'         => $validator->errors(),
                    'data'          => $request->all()
                ]);
            } else {
                if ($this->teamExist($request->name)) {
                    return response()->json([
                        'message'       => 'Team Already Exist',
                        'statusMessage' => 'failure',
                        'statusCode'    => 409,
                        'data'          => $request->all()
                    ]);
                } else {
                    $team->name = $request->name;
                    $team->logo_url = $request->logo_url;
                    $team->save();
                    return response()->json([
                        'message'       => 'Team updated Successfully',
                        'statusMessage' => 'success',
                        'statusCode'    => 200,
                        'data'          => $team
                    ]);
                }
            }
        } else {
            return response()->json([
                'message'       => 'Unauthorized Access',
                'statusMessage' => 'unauthorized',
                'statusCode'    => 400,
                'data'          => $request->all()
            ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Team  $team
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, Team $team)
    {
        if ($this->isAllowed($request->user(),'delete')) {
            $team->delete();
            return response()->json([
                'message'       => 'Team deleted Successfully',
                'statusMessage' => 'success',
                'statusCode'    => 200
            ]);
        } else {
            return response()->json([
                'message'       => 'Unauthorized Access',
                'statusMessage' => 'unauthorized',
                'statusCode'    => 400,
                'data'          => $request->all()
            ]);
        }
    }

    // Custom Functions Start
    private function teamExist($name){
        if(Team::where('name', $name)->exists()){
            return true;
        } else {
            return false;
        }
    }
    // Custom Function End
}
