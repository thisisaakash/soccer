<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TeamController;
use App\Http\Controllers\PlayerController;
use App\Http\Controllers\API\AuthController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::middleware('auth:sanctum')->group(function () {
    // Team
    Route::post('teams',[TeamController::class,'store']);
    Route::put('teams/{team}',[TeamController::class,'update']);
    Route::delete('teams/{team}',[TeamController::class,'destroy']);

    // Players
    Route::post('players',[PlayerController::class,'store']);
    Route::put('players/{player}',[PlayerController::class,'update']);
    Route::delete('players/{player}',[PlayerController::class,'destroy']);
});

// Teams Read
Route::get('teams',[TeamController::class,'index']);
Route::get('teams/{team}',[TeamController::class,'show']);

// Player Read
Route::get('players',[PlayerController::class,'index']);
Route::get('players/{player}',[PlayerController::class,'show']);

// User Register / Login
Route::post('register',[AuthController::class,'register']);
Route::post('login',[AuthController::class,'login']);

Route::get('teams/{team}/players',[PlayerController::class,'getTeamPlayers']);

/*
Route::apiResource('teams',TeamController::class);
Route::apiResource('players',PlayerController::class);
*/
