<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRolesPermission extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('roles_permission', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('permission');
            $table->timestamps();
        });

        // Insert Default Roles and Permission
        DB::table('roles_permission')->insert(
            array(
                'name' => 'admin',
                'permission' => '*'
            )
        );

        DB::table('roles_permission')->insert(
            array(
                'name' => 'user',
                'permission' => 'read'
            )
        );
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('roles_permission');
    }
}
